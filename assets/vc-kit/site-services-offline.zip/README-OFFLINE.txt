Site Services · VC Kit offline pack
=================================

1. Open offline/index.html in any browser (self-contained hub).
2. On the live Vercel site, kit binaries use absolute URLs:
   https://bv-documentation-suite.vercel.app/assets/vc-kit/vc_template_pack_v1_0.xlsx
   https://bv-documentation-suite.vercel.app/assets/vc-kit/vc_template_pack_v1_0_mapped_sample.xlsx
   https://bv-documentation-suite.vercel.app/assets/vc-kit/vc_mapper_package.zip
   https://bv-documentation-suite.vercel.app/assets/vc-kit/AI_REBUILD_PROMPT.txt
3. For runnable mapper tooling, also download vc_mapper_package.zip from the live suite.
4. Cost model snapshots: use Export HTML report on /cost-model (and Deal A / Deal B).
5. AI rebuild prompt: docs/AI_REBUILD_PROMPT.txt (also at /assets/vc-kit/AI_REBUILD_PROMPT.txt).

No customer deal data is included. Generic starter samples only.
