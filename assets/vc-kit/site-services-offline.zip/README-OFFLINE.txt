Site Services · VC Kit offline pack
=================================

1. Open offline/index.html in any browser (self-contained hub).
2. For runnable mapper tooling, also download vc_mapper_package.zip from the live suite
   (/assets/vc-kit/vc_mapper_package.zip) — Excel + Python stay in that package.
3. Cost model snapshots: use Export HTML report on /cost-model (and Deal A / Deal B).

No customer deal data is included. Generic starter samples only.
